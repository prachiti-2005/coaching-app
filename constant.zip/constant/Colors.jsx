export default{
    WHITE : '#fff',
    PRIMARY : '#0075ff'
}